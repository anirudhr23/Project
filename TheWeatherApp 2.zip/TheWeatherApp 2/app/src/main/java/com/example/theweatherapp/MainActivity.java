package com.example.theweatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private TextView textView;
    private TextView textView2;
    private TextView textView3;
    private TextView textView4;
    private SensorManager sensorManager;
    private Sensor tempSensor;
    private Sensor humidtySensor;
    private Sensor pressureSensor;
    private Sensor lightSensor;
    private Boolean isTemperatureSensorAvailable;
    private Boolean isHumiditySensorAvailable;
    private Boolean isPressureSensorAvailable;
    private Boolean isLightSensorAvailable;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);
        textView4 = findViewById(R.id.textView4);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        if(sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE) != null)
        {
            tempSensor = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);
            isTemperatureSensorAvailable = true;
        }else {
            textView.setText(getString(R.string.sensor_message_temperature));
            isTemperatureSensorAvailable = false;
        }
        if(sensorManager.getDefaultSensor(Sensor.TYPE_RELATIVE_HUMIDITY) != null)
        {
            humidtySensor = sensorManager.getDefaultSensor(Sensor.TYPE_RELATIVE_HUMIDITY);
            isHumiditySensorAvailable = true;
        }else {
            textView2.setText(getString(R.string.sensor_message_humidity));
            isHumiditySensorAvailable = false;
        }
        if (sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE) != null) {
            pressureSensor = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE);
            isPressureSensorAvailable = true;
        } else {
            textView3.setText(getString(R.string.sensor_message_pressure));
        }
        if (sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT) != null) {
            lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
            isLightSensorAvailable = true;
        } else {
            textView3.setText(getString(R.string.sensor_message_light));
        }


    }


    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

        if (sensorEvent.sensor.getType() == Sensor.TYPE_AMBIENT_TEMPERATURE) {
            float temperatureValue = sensorEvent.values[0];
            String formattedTemperature = String.format("%.2f", temperatureValue);
            textView.setText(getString(R.string.temperature_format, formattedTemperature));
        } else if (sensorEvent.sensor.getType() == Sensor.TYPE_RELATIVE_HUMIDITY) {
            float humidityValue = sensorEvent.values[0];
            String formattedHumidity = String.format("%.2f", humidityValue);
            textView2.setText(getString(R.string.humidity_format, formattedHumidity));
        } else if (sensorEvent.sensor.getType() == Sensor.TYPE_PRESSURE) {
            float pressureValue = sensorEvent.values[0];
            String formattedPressure = String.format("%.2f", pressureValue);
            textView3.setText(getString(R.string.pressure_format, formattedPressure));
        }
        else if (sensorEvent.sensor.getType() == Sensor.TYPE_LIGHT) {
            float lightValue = sensorEvent.values[0];
            String formattedLight = String.format("%.2f", lightValue);
            textView4.setText(getString(R.string.light_format, formattedLight));
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        if(isTemperatureSensorAvailable)
        {
            sensorManager.registerListener(this, tempSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }

        if (isHumiditySensorAvailable) {
            sensorManager.registerListener(this, humidtySensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
        if (isPressureSensorAvailable) {
            sensorManager.registerListener(this, pressureSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
        if (isLightSensorAvailable) {
            sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(isTemperatureSensorAvailable)
        {
            sensorManager.unregisterListener(this);
        }
        if (isLightSensorAvailable) {
            sensorManager.unregisterListener(this);
        }
        if (isHumiditySensorAvailable) {
            sensorManager.unregisterListener(this);
        }
        if (isPressureSensorAvailable) {
            sensorManager.unregisterListener(this);
        }
    }
}